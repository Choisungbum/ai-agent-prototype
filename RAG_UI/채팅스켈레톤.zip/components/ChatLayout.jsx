import {useEffect, useRef, useState} from "react"
import MessageList from "./MessageList";
import ChatInput from "./ChatInput";

function ChatLayout() {
    // 메시지 상태 및 입력 대기 상태
    const [messages, setMessages] = useState([
        { role: "assistant", content: "안녕하세요, 무엇을 도와드릴까요?" }
    ]);
    const [isTyping, setIsTyping] = useState(false);

    // 자동 스크롤 상태
    const [autoScroll, setAutoScroll] = useState(true);

    // DOM 참조
    const bottomRef = useRef(null);
    const containerRef = useRef(null);
    const isAutoScrollingRef = useRef(false);

    // 메시지 전송 핸들러
    const handleSendMessage = (text) => {
        // 사용자 메시지 추가
        setMessages(prevMessages => [
            ...prevMessages,
            { role: "user", content: text }
        ]);

        // assistant typing 효과 시작
        setIsTyping(true);

        // 1초 후 assistant 답변 추가
        setTimeout(() => {
            setIsTyping(false);
            setMessages(prevMessages => [
                ...prevMessages,
                { role: "assistant", content: '답변' + text }
            ]);
        }, 1000);
    };

    // 스크롤 이벤트 핸들러
    const handleScroll = () => {
        if (isAutoScrollingRef.current) return;
        
        const el = containerRef.current;
        if (!el) return;

        // 하단임을 판단하여 autoScroll 상태 갱신
        const atBottom = (el.scrollHeight - el.scrollTop - el.clientHeight) < 5;
        setAutoScroll(atBottom);
    };

    // 최신 메시지로 스크롤 이동
    const scrollToBottom = () => {
        isAutoScrollingRef.current = true;

        bottomRef.current?.scrollIntoView({ behavior: "smooth" });
        setAutoScroll(true);

        // smooth scroll 끝날 시간 후 해제
        setTimeout(() => {
            isAutoScrollingRef.current = false;
        }, 300);
    };

    // useRef = DOM을 직접 가리키는 포인터
    // bottomRef.current = 실제 DOM 요소
    useEffect(() => {
    
        if (!autoScroll) return;

        isAutoScrollingRef.current = true;

        // scrollIntoView({ behavior: "smooth" }); -> 이 요소가 보이도록 부모 스크롤 컨테이너를 움직여라
        bottomRef.current?.scrollIntoView({behavior: "smooth"});

        const timer = setTimeout(() => {
            isAutoScrollingRef.current = false;
        }, 300);
        
        return () => clearTimeout(timer);

    }, [messages, isTyping, autoScroll]);


    return (
        <div className="app-container">
            <div className="chat-wrapper">
                <header className="chat-header">
                Chat UI
                </header>

                <div className="chat-main"
                 ref={containerRef}
                 onScroll={handleScroll}     
                >
                    <MessageList messages={messages} isTyping={isTyping} />

                    {/* 스크롤 기준점 */}
                    <div ref={bottomRef} />
                </div>
                    {/* 최신 메시지로 이동 */}
                    {!autoScroll && (
                        <button
                            className="scroll-to-bottom"
                            onClick={scrollToBottom}
                        >
                            ↓ 최근 메세지
                        </button>
                    )}

                <footer className="chat-footer">
                <ChatInput onSend={handleSendMessage} />
                </footer>
            </div>
        </div>
  );
}

export default ChatLayout;